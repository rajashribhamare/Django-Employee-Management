from django.urls import path
from .views import student_register, student_list

urlpatterns = [
    path('register/', student_register, name='student_register'),
    path('students/', student_list, name='student_list'),
]

