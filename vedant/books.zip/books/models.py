from django.db import models

# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=255)  # Book title
    author = models.CharField(max_length=255)  # Book author
    publication_date = models.DateField()  # Date of publication
    created_at = models.DateTimeField(auto_now_add=True)  # Auto timestamp on creation

    def __str__(self):
        return f"{self.title} by {self.author}"  # Display title and author in admin panel
