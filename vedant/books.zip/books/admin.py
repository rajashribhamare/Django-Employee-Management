from django.contrib import admin

# Register your models here.
from .models import Book

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'publication_date', 'created_at')  # Show these fields in admin
    search_fields = ('title', 'author')  # Enable search
    list_filter = ('publication_date',)  # Add filter for publication date
