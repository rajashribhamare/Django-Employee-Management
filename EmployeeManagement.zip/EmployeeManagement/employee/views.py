from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from .models import Employee
from .forms import EmployeeForm


def employee_register(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thank_you')
    else:
        form = EmployeeForm()
    return render(request, 'register.html', {'form': form})

def thank_you(request):
    return render(request, 'thank_you.html')
